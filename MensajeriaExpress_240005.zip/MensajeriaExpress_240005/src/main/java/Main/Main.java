/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Main;

/**
 *
 * @author Chris
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
